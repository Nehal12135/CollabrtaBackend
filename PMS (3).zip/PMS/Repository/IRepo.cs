﻿using PMS.Models;

namespace PMS.Repository
{
    public interface IRepo
    {
        public IEnumerable<Product> getproducts();

        public string createproduct(Product p);


        public string addcart(Cart cart);

        public IEnumerable<Cart> getcartlist(string UserName);
    }
}
