﻿using Microsoft.EntityFrameworkCore;
using PMS.Models;
using Microsoft.Data.SqlClient;

namespace PMS.Repository
{
    public class Repo:IRepo
    {
        private readonly customdbContext _customdbContext;

        public Repo(customdbContext customdContext)
        {
            _customdbContext = customdContext;
        }


        public IEnumerable<Product> getproducts()
        {
            return _customdbContext.Products;
        }

        public string createproduct(Product p)
        {
            _customdbContext.Products.Add(p);
            _customdbContext.SaveChanges();
            return "OK";
        }

        public IEnumerable<Cart> getcartlist(string UserName)
        {
            var param = new SqlParameter[]
            {
                new SqlParameter(){
                    ParameterName = "@UserName",
                    SqlDbType=System.Data.SqlDbType.VarChar,Direction=System.Data.ParameterDirection.Input,Value=UserName}
            };

            return _customdbContext.getCartListbyUserName.FromSqlRaw("[dbo].[getCartListbyUserName] @UserName", param).AsEnumerable().ToList();
        }


        public string addcart(Cart cart)
        {
            var param = new SqlParameter[]
            {
                new SqlParameter()
                {
                ParameterName = "@productID",
                SqlDbType = System.Data.SqlDbType.Int,
                Direction = System.Data.ParameterDirection.Input,
                Value = cart.productID

                },

                new SqlParameter()
                {
                    ParameterName = "@productName",
                    SqlDbType = System.Data.SqlDbType.VarChar,
                    Direction = System.Data.ParameterDirection.Input,
                    Value =cart.productName
                },

                new SqlParameter()
                {
                    ParameterName = "@productPrice",
                    SqlDbType = System.Data.SqlDbType.Decimal,
                    Direction = System.Data.ParameterDirection.Input,
                    Value =cart.productPrice
                },
                 new SqlParameter()
                {
                    ParameterName = "@imageUrl",
                    SqlDbType = System.Data.SqlDbType.VarChar,
                    Direction = System.Data.ParameterDirection.Input,
                    Value =cart.imageUrl
                },
                 new SqlParameter()
                {
                    ParameterName = "@quantity",
                    SqlDbType = System.Data.SqlDbType.Int,
                    Direction = System.Data.ParameterDirection.Input,
                    Value =cart.quantity
                },

           
                 new SqlParameter()
                {
                    ParameterName = "@totalPrice",
                    SqlDbType = System.Data.SqlDbType.Decimal,
                    Direction = System.Data.ParameterDirection.Input,
                    Value =cart.totalPrice
                },
                 new SqlParameter()
                {
                    ParameterName = "@UserName",
                    SqlDbType = System.Data.SqlDbType.VarChar,
                    Direction = System.Data.ParameterDirection.Input,
                    Value =cart.UserName
                },
            };

            _customdbContext.SaveChanges();

            int intitem = _customdbContext.Database.ExecuteSqlRaw("[dbo].[createcarlistforUser] @productID,@productName,@productPrice,@imageUrl,@quantity,@totalPrice,@UserName", param);


            return "Ok";
        }
    }
}