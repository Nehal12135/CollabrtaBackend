﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PMS.Models;
using PMS.Repository;

namespace PMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IRepo _repo;

        public ProductController(IConfiguration configuration, IRepo repo)
        {
            _configuration = configuration;
            _repo = repo;
        }
        [HttpGet]
        public IEnumerable<Product> getproducts()
        {
            return _repo.getproducts();
        }
        [HttpPost]
        [Route("createproduct")]
        public IActionResult Create([FromBody] Product c)
        {

            var status = _repo.createproduct(c);

            if (status == "OK")
            {
                return Ok(new { message = "product added successfully!" });
            }
            else
            {
                return StatusCode(429, status);
            }
        }

        /*[HttpPost]
        [Route("createproduct")]
        public IActionResult Create([FromBody] Product c)
        {

            var status = _repo.createproduct(c);

            if (status == "OK")
            {
                return Ok(new { message = "product added successfully!" });
            }
            else
            {
                return StatusCode(429, status);
            }
        }


        [HttpPost]
        [Route("createcart")]
        public IActionResult createcart([FromBody] Cart c)
        {

            var status = _repo.createcart(c);

            if (status == "OK")
            {
                return Ok(new { message = "product added successfully!" });
            }
            else
            {
                return StatusCode(429, status);
            }
        }*/
    }
}