﻿using Microsoft.EntityFrameworkCore;

namespace JWT.Models
{
    public class CustomDbContext:DbContext
    {
        public DbSet<usermodels> UserReg { get; set; }

        public static string Connectionstring
        {
            get;
            set;
        }
        public void BuildConnectionstring(string dbstring) { Connectionstring = dbstring; }

        public CustomDbContext(DbContextOptions<CustomDbContext> options) : base(options)
        {

        }
        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Register>(eb =>
            {
                eb.HasKey("UserName");
            });
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!string.IsNullOrEmpty(Connectionstring))
            {
                optionsBuilder.UseSqlServer(Connectionstring);
            }
        }
    }
}