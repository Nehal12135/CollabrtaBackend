﻿namespace JWT.Models
{
    public class SecurityTokeModel
    {
        public string? auth_token { get; set; }
    }
}
