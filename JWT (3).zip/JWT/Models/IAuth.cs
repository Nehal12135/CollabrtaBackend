﻿namespace JWT.Models
{
    public interface IAuth
    {
        SecurityTokeModel GenerateToken(string UserName, string Password);
    }
}
