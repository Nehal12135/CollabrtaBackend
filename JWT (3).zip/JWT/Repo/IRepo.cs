﻿using JWT.Models;

namespace JWT.Repo
{
    public interface IRepo
    {
        public string createCustomers(Register register);
    }
}
